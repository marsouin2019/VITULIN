<form class="text-center" action="traitement.php" method="POST" id="frmRegister">

            <p class="h4 mb-4">Se connecter</p>

           
            <!-- E-mail -->
            <input type="email" name="email" id="email" class="form-control mb-4" placeholder="E-mail">

            <!-- Password -->
            <input type="password" name="password" id="password" class="form-control" placeholder="Password"
              aria-describedby="defaultRegisterFormPasswordHelpBlock">

            <!-- Sign up button -->
            <button class="btn btn-info my-4 btn-block" name="frmForm" value="frmLogin" type="submit">Se connecter</button>


            <hr>

           

</form>
<form action="traitement.php" method="POST" id="frmUpdate" class="text-center border border-light p-5">

<p class="h4 mb-4">Modifier votre profil</p>

<!-- E-mail -->
<div class="form-group">

    <select id="civilite" name="civilite" class="form-control" required>
            <option value="M" selected>M</option>
            <option value="Mme">Mme</option>
    </select>
</div>
<div class="form-row mb-4">
    <div class="col">
        <!-- First name -->
        <input type="text" id="lastname" name="lastname" class="form-control" placeholder="Nom..." value="<?php echo $_SESSION["nom"]?>">
    </div>
    <div class="col">
        <!-- Last name -->
        <input type="text" id="firstname" name="firstname" class="form-control" placeholder="Prénom..." value="<?php  echo $_SESSION["prenom"]?>">
    </div>
</div>


<!-- E-mail -->
<input type="text" id="username" name="username" class="form-control mb-4" placeholder="Pseudo"  value="<?php echo $_SESSION["username"]?>">


<!-- E-mail -->
<input type="email" id="email" name="email" class="form-control mb-4" placeholder="E-mail"  value="<?php  echo $_SESSION["email"]?>" readonly>



<div class="form-row mb-4">
    <div class="col">
        <!-- Adresse -->
        <input type="text" id="adress" name="adress" class="form-control" placeholder="Adresse"  value="<?php echo $_SESSION["adress"]?>">
    </div>
    <div class="col">
        <!-- Code Postal -->
        <input type="text" id="codepostal" name="codepostal" class="form-control" placeholder="Code Postal"  value="<?php echo $_SESSION["codepostal"]?>"> 
    </div>
</div>
<!-- Adressc -->
<input type="text" id="adressc" name="adressc" class="form-control mb-4" placeholder="Adresse complémentaire"  value="<?php echo $_SESSION["adressc"]?>">

<!--telephone-->
<input type="phone" id="telephone" name="telephone" class="form-control mb-4" placeholder="Numéro de téléphone"  value="<?php echo $_SESSION["telephone"]?>">


<!-- Ville -->
<input type="text" id="ville" name="ville" class="form-control mb-4" placeholder="Ville"  value="<?php echo $_SESSION["ville"]?>">

<div class="form-group">
    <label>Pays</label><br>
    <select name="pays" id="pays" class="form-control">
            <option value="Martinique">Martinique</option>
            <option value="Guadeloupe">Guadeloupe</option>
    </select>
</div>
<button type="button" class="btn btn-danger">Annuler</button>
<button type="submit" class="btn btn-success" name="frmForm" value="frmUpdate">Mettre à jour</button>

</form>
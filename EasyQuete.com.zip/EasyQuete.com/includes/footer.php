



<!-- Barre d'information vente-->
         
<div class="col-12">
 <div class="row">
   <div class="col-sm">
     <img src="img/Sans titre 4.png" alt="">
     Service Après-Vente
   </div>
   <div class="col-sm">
     <img src="img/ICONE - Paiement sécurisé - Gris2.png" alt="" height="100px">
     Paiement Sécurisé
   </div>
   <div class="col-sm">
     <img src="img/guarantee.png" alt="" srcset="" height="100px">
     Garantie sur les produits
   </div>
   <div class="col-sm">
     <img src="img/icone-hotline2.png" alt="" srcset="" height="100px">
     Service Après-vente
   </div>
 </div>
</div>

<!--Barre réseau sociaux & paiement-->
<div class="container">
<div class="row">
<div class="col">
<img src="img/instagram.png" alt="" srcset="" height="45px">
<img src="img/watsaap.png" alt="" srcset="" height="50px">
<img src="img/twiter.png" alt="" srcset="" height="50px">
<img src="img/Facebook2.png" alt="" srcset="" height="50px">
<img src="img/snap.png" alt="" srcset="" height="50px">
</div>
<div class="col">
<img src="img/american_express_512_icon-icons.com_75968.png" alt="" srcset="" height="55px">
<img src="img/businesspaymentcard_paymentcard_visa_negocio_pag_2339.png" alt="" srcset="" height="52px">
<img src="img/mastercard_512_icon-icons.com_75982.png" alt="" srcset="" height="55px">
<img src="img/paypal_512_icon-icons.com_75983.png" alt="" srcset="" height="55px">
</div>
</div>




<!-- Footer -->
<footer class="footer">

<!-- Footer Links -->
<div class="container text-center text-md-left">

<!-- Grid row -->
<div class="row">

<!-- Grid column -->
<div class="col-md-3 mx-auto">

<!-- Links -->
<h5 class="font-weight-bold text-uppercase mt-3 mb-4">Catégorie</h5>

<ul class="list-unstyled">
 <li>
   <a href="homme.php">Homme</a>
 </li>
 <li>
   <a href="femme.php">Femme</a>
 </li>
 <li>
   <a href="enfants.php">Enfant</a>
 </li>
 <li>
   <a href="nouveautes.php">Nouveautés</a>
 </li>
 <li>
   <a href="bonnes_affaires.php">Bonnes Affaires</a>
 </li>
</ul>

</div>
<!-- Grid column -->

<hr class="clearfix w-100 d-md-none">

<!-- Grid column -->
<div class="col-md-3 mx-auto">

<!-- Links -->
<h5 class="font-weight-bold text-uppercase mt-3 mb-4">Encore + de Mode </h5>

<ul class="list-unstyled">
 <li>
   <a href="actu.php">Blog</a>
 </li>
 <li>
   <a href="apropos.php">Qui somme nous ?</a>
 </li>
 <li>
   <a href="devenonspartenaire.php">Devenons partenaire</a>
 </li>
<!-- <li>
   <a href="#!">Link 4</a>
 </li> 
-->
</ul>

</div>
<!-- Grid column -->

<hr class="clearfix w-100 d-md-none">

<!-- Grid column 
<div class="col-md-3 mx-auto">

<h5 class="font-weight-bold text-uppercase mt-3 mb-4">Aide & Information</h5>

<ul class="list-unstyled">
 <li>
   <a href="#!">Assistance</a>
 </li>
 <li>
   <a href="#!">Suivi commande</a>
 </li>
 <li>
   <a href="#!">Link 3</a>
 </li>
 <li>
   <a href="#!">Link 4</a>
 </li>
</ul>

</div>
-->
<!-- Grid column -->

<hr class="clearfix w-100 d-md-none">

<!-- Grid column -->
<div class="col-md-3 mx-auto">

<!-- Links -->
<h5 class="font-weight-bold text-uppercase mt-3 mb-4">En savoir plus</h5>

<ul class="list-unstyled">
 <li>
   <a href="faq.php">FAQ/Aide</a>
 </li>
 <li>
   <a href="#!">Mention légale</a>
 </li>
 <li>
   <a href="contact.php">Contact</a>
 </li>
 <li>
   <a href="livraison&retour.php">Livraison & Retour</a>
 </li>
 <li>
   <a href="#!">Condition général</a>
 </li>
</ul>

</div>
<!-- Grid column -->

</div>
<!-- Grid row -->

</div>
<!-- Footer Links -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2019 Copyright:
<a href="https://mdbootstrap.com/education/bootstrap/"> EasyQuete</a>
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>
<script src="js/produit.js" ></script>

</body>

</html>

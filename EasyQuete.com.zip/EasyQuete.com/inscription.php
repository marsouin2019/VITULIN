
<?php
    session_start();

    include("includes/header.php");
    
    
?>



<div class="container">
    <div class="col-12">
<!-- Default form register -->
<?php
include("includes/forms/inscription.php");

?>

    </div>
</div>





                                                                                  <!--Footer-->

<?php
    include("includes/footer.php")
?> 


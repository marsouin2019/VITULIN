<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
<link rel="stylesheet" href="css/mdb.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/apropos.css">
<link rel="stylesheet" href="css/index.css">
<title>EasyQuete</title>
  </head>
  <body>
    

                                                                             <!--header-->
                                                                                 <?php
                                                                    include("includes/header.php")
                                                                                 ?>

  

<!--Qui sommes-nous ?-->


<div class="container mt-5">


        <!--Section: Content-->
        <section class="dark-grey-text text-center">
          
          <!-- Section heading -->
          <h3 class="font-weight-bold mb-4 pb-2">À propos d'EasyQuete</h3>
          <!-- Section description 
          <p class="grey-text w-responsive mx-auto mb-5">Tout ce que vous vouliez savoir sur votre site de mode preféré.</p> -->
      
            <!-- Grid row -->
          <div class="row">
      
            <!-- Grid column -->
            <div class="col-lg-3 col-md-6 mb-4">
              <!-- Collection card -->
              <div class="card collection-card z-depth-1-half">
                <!-- Card image -->
                <div class="view zoom">
                  <a href="qui_sommes_nous.php"><img src="https://mdbootstrap.com/img/Photos/Horizontal/E-commerce/Vertical/5.jpg" class="img-fluid"
                    alt=""></a>
                  <div class="stripe dark">
                    <a>
                      <p><strong>Qui sommes nous ?</strong> 
                        
                      </p>
                    </a>
                  </div>
                </div>
                <!-- Card image -->
              </div>
              <!-- Collection card -->
            </div>
            <!-- Grid column -->
      
            <!-- Grid column -->
            <div class="col-lg-3 col-md-6 mb-4">
              <!-- Collection card -->
              <div class="card collection-card z-depth-1-half">
                <!-- Card image -->
                <div class="view zoom">
                  <a href="marques.php"><img src="https://mdbootstrap.com/img/Photos/Horizontal/E-commerce/Vertical/8.jpg" class="img-fluid"
                    alt=""></a>
                  <div class="stripe light">
                    <a>
                      <p><strong>Les marques d'EasyQuete</strong> 
                        
                       
                        
                      </p>
                    </a>
                  </div>
                  
                </div>
                
                <!-- Card image -->
              </div>

              <a href="index.php"><button type="button" class="btn btn-danger btn-rounded">Retour à la boutique</button></a>
              <!-- Collection card -->
            </div>
            <!-- Grid column -->
      
            <!-- Grid column -->
            <div class="col-lg-3 col-md-6 mb-4">
              <!-- Collection card -->
              <div class="card collection-card z-depth-1-half">
                <!-- Card image -->
                <div class="view zoom">
                  <a href="experiences.php"><img src="https://mdbootstrap.com/img/Photos/Horizontal/E-commerce/Vertical/9.jpg" class="img-fluid"
                    alt=""></a>
                  <div class="stripe dark">
                    <a>
                      <p><strong>L'expérience d'EasyQuete</strong>
                        
                      </p>
                    </a>
                  </div>
                </div>
                <!-- Card image -->
              </div>
              <!-- Collection card -->
            </div>
            <!-- Grid column -->
      
           
            <!-- Fourth column -->
      
          </div>
          <!-- Grid row -->
      
        </section>
        <!--Section: Content-->
      
      
      </div>

                                                                          <!--Footer-->

                                                                              <?php
                                                                   include("includes/footer.php")
                                                                              ?> 


    

  </body>
</html>












 <?php
    session_start();
    include("includes/header.php");
    
?>
 <body>
 
                                                                            <!--header-->



  <div class="container my-5 py-5 z-depth-1">

 
    <!--Section: Content-->
    <section class="px-md-5 mx-md-5 text-center text-lg-left dark-grey-text">


      <!--Grid row-->
      <div class="row d-flex justify-content-center">

        <!--Grid column-->
        <div class="col-md-6">

          <!-- Default form register -->
          <?php
            include("includes/forms/formconexion.php");
          ?>
          <!-- Default form register -->

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->


    </section>
    <!--Section: Content-->


  </div>


                                                                          <!--Footer-->

                                                                              <?php
                                                                 include("includes/footer.php");
                                                                              ?>

 
 




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
<link rel="stylesheet" href="css/mdb.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/index.css">

<title>EasyQuete</title>
  </head>
  <body>


                                                                    <!--header-->
                                                                          <?php
                                                                    include("includes/header.php")
                                                                          ?>


    
        <div class="container z-depth-1 my-5 py-5">

                <!-- Section -->
                <section>
                  
                  <style>
                    .border-top {
                      border-top-width: 2px !important;
                    }
                    </style>
              
                  
                  <h3 class="font-weight-bold text-center dark-grey-text pb-2">Livraison & Retour</h3>
                  <hr class="w-header my-4">
                  <p class="lead text-center text-muted pt-2 mb-5">Join thousands of satisfied customers using our template
                    globally.</p>
              
                  <div class="row d-flex justify-content-center">
              
                    <div class="col-md-6 col-lg-5 col-xl-4">
                      <h5 class="font-weight-normal border-top border-light pt-4 mb-4"><a class="dark-grey-text" href="#">Livraison</a></h5>
                      <p class="text-muted mb-5 pb-md-3">Written enquire painful to offices forming it. Then so does over sent
                        dull. Likewise offended humour mrs
                        fat trifling answered. On ye position greatest so desirous enable performance based.</p>
                    </div>
              
                    <div class="col-md-6 col-lg-5 col-xl-4">
                      <h5 class="font-weight-normal border-top border-secondary pt-4 mb-4"><a class="dark-grey-text"
                          href="#">Retour</a></h5>
                      <p class="text-muted mb-5 pb-md-3">Written enquire painful to offices forming it. Then so does over sent
                        dull. Likewise offended humour mrs
                        fat trifling answered. On ye position greatest so desirous enable performance based.</p>
                    </div>
              
                    <div class="w-100"></div>
              
                    
              
                  </div>
                </section>
                <!-- Section -->
              
              </div>
    


                                                                            <!--Footer-->

                                                                               <?php
                                                                    include("includes/footer.php")
                                                                                ?> 
    
       
   
<script src="js/paiement.js"></script>


  </body>
</html>











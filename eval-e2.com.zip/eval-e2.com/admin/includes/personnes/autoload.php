<?php
    
    include("../class/connect.php");
    include("../class/cl_traitement.php");

?>
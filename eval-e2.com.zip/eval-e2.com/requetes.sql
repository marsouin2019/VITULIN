INSERT INTO personnes SET nom='LAVA',prenom='whatever',civilite='M',postal='97232',telephone='0696458712';


